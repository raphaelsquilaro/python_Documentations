/* ===================================================
   ELEMENTS
=================================================== */
const menuButton = document.getElementById("menuButton");
const nav = document.getElementById("nav");
const revealElements = document.querySelectorAll(".reveal");

/* ===================================================
   MOBILE MENU
=================================================== */
menuButton?.addEventListener("click", () => {
    // O ponto de interrogação (?) garante que o código só roda se o elemento existir
    nav?.classList.toggle("active");
});

/* ===================================================
   REVEAL ANIMATION (Intersection Observer)
=================================================== */
const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
        if (entry.isIntersecting) {
            entry.target.classList.add("active");
        }
    });
}, {
    threshold: 0.15
});

revealElements.forEach((element) => {
    observer.observe(element);
});